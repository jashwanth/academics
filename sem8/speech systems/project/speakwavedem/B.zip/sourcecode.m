% 
% WAVELET SPEAKER RECOGNITION SYSTEM
% 
% In order to obtain the complete source code for Wavelet Speaker Recognition System
% please visit my website
% 
% http://www.advancedsourcecode.com/waveletspeaker.asp
% 
% For any question please email me luigi.rosa@tiscali.it
%
% Luigi Rosa
% Via Centrale 35
% 67042 Civita di Bagno
% L'Aquila - ITALY 
% email  luigi.rosa@tiscali.it
% mobile +39 320 7214179
% website http://www.advancedsourcecode.com
%
