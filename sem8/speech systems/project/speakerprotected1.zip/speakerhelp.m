% 
% SPEAKER RECOGNITION SYSTEM
%
% In order to obtain the complete source code please visit
% 
% http://www.advancedsourcecode.com/speaker.asp
%
% A small donation (just 26 Euros, less than 36,4 U.S. Dollars) is required.
% 
% Date              Release           Major features
% 
% 2005.12.07        1.0               - Speaker recognition
%                                     - Improved metric
%                                     - Interactive and intuitive GUI
%                                     - Microphone utilities
%                                     - Easy c/c++ implementations
%
%
% For more informations please email me ( luigi.rosa@tiscali.it )
% 
% Luigi Rosa
% Via Centrale 35
% 67042 Civita di Bagno
% L'Aquila - ITALY 
% email luigi.rosa@tiscali.it
% mobile +39 3207214179 
% website http://www.advancedsourcecode.com
%
%