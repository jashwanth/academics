Unzip all files in Matlab current directory and type "speechrecognition" on Matlab command window.
A simple and intuitive GUI should appear.

In order to obtain the complete source code please visit

http://www.advancedsourcecode.com/speech.asp


Luigi Rosa
Via Centrale 35
67042 Civita di Bagno
L'Aquila - ITALY 
email luigi.rosa@tiscali.it
mobile +39 3207214179 
website http://www.advancedsourcecode.com