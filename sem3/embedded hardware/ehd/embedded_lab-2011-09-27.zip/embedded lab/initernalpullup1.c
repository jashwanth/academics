#include<avr/io.h>
#include<avr/delay.h>
#define PORT PORTA
#define DDR DDRA
int main(void)
{
   
   DDR=0b11011111;
   PORT=0b00100000;
   unsigned int x;
   while(1)
   {
      x=PINA&&0b00100000;
	  if(x==0)
	  {
	    PORT |= 0b00000001;
      } 
      else
      {
        PORT &= 0b11111110;
	  }
	}
}
	 
   