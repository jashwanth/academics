#include<avr/io.h>
#include<util/delay.h> 
int main(void)
 { 
  DDRA = 0x01;
  PORTA = 0x02;
  SFIOR = ~(1<< PUD);
  int x;
  while(1)
  {
	x=PINA&0x02;
	if(x==2)
	{
		PORTA&=0xFE;
		
		_delay_ms(50);
	}
	else
	{
		PORTA|=0x01;
		_delay_ms(50);
	}
  }
  return 0;
}
	
	
	
  
  