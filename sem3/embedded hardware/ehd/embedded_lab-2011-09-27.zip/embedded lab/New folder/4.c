#include<avr/io.h>
#include<util/delay.h>
void pwm()
{
	TCCR1A|=0x02;
	TCCR1A&=0xFE;
	TCCR1B|=0x10;
	TCCR1B&=0xF7;
	TCCR1A|=0x80;
	TCCR1A&=0xBF;
	TCCR1B|=0x02;
	TCCR1B&=0xFA;
	ICR1=0x00FF;
}

void init()
{
	ADCSRA|=0x40;
	ADCSRA|=0x07;
}

main()
{
	DDRD=0x20;
	OCR1A=0x0078;
	pwm();
	if(ADC0-ADC1>10)
	{
		OCR1A=-(0.1*(ADC0-ADC1));
	}
}
	