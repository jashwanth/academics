#include<avr/io.h>
#include<avr/delay.h>
#define PORT PORTD
#define DDR DDRD
int main(void)
{
DDR = 0xF0;
PORT = 0x0F;
SFIOR &= 0b11111011;
int x;
while(1){
PORT = 0x0F;
x = PIND & 0x0F;
if (x>0){
	PORT = 0xF0;
}
}

/*int x;
while(1)
{
	x = PIND & 0x0F;
	if(x>0){
	PORT = 0x00;_delay_ms(400);
	}
	else{
	PORT = 0x0F;_delay_ms(400);
	}
}*/
}