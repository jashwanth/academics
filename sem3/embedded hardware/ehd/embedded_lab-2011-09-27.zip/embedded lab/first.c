#include<avr/io.h>
#include<avr/delay.h>
#define PORT PORTB
#define DDR DDRB
int main(void)
{
	DDR=0xFF;
	PORT=0x00;
	while(1)
	{
		for(int i=0;i<8;i++)
			PORT=(1<<i),_delay_ms(800);
		for(int i=7;i>=0;i--)
			PORT=(1<<i),_delay_ms(500);
	}
	return 0;
}
			