#include<avr/io.h>
#include<avr/delay.h>
#define PORT PORTB
#define DDR DDRB
int main(void)
{
	DDRA=0x01;
	while(1)
	{
	   if(PINA & 0b00000010)
	   {
	      PORTA = 0x00;
	   }
	   else{
			PORTA=0x01;
		}
	}
}	   
			