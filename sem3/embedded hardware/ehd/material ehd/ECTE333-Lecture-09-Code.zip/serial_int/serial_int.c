// ECTE333 - Spring session
// C progam for STK500 board & ATmega16 chip
// The program intercepts USART RX Complete interrupt and 
// display the received character on port B
// Connections: PORTD.0 -> RXD pin spare
//              PORTD.1 -> TXD pin spare
// 			    PORT B  -> LEDs
// Serial tranmission parameters with Hyper Terminal: 1200 8N1
// Written by Lam Phung [phung@uow.edu.au]

#include <avr/io.h>
#include <avr/interrupt.h>

void USART_init(void){
    // Normal speed, disable multi-proc
	UCSRA = 0b00000000; 

    // Enable Tx and Rx, enable RX interrupt
	UCSRB = 0b10011000; 

    // Asynchronous mode, no parity, 1 stop bit, 8 data bits
	UCSRC = 0b10000110; 

	// Baud rate 1200bps, assuming 1MHz clock
	UBRRL = 0x33; UBRRH = 0x00;
}

// Interrupt service routine
ISR(USART_RXC_vect){
	PORTB = UDR;  // Received character is displayed on port B
}

int main(void) {
	USART_init(); // initialise USART
	sei();        // enable interrupt subsystem globally 
	DDRB = 0xFF;  // set port B for output
	while (1) {;} // infinite loop
	return 0;
}
