// ECTE333 - Microcontroller Architecture and Applications
// Spring session
// Using Timer 1 Overflow Interrupt INT1 in ATmega16
// The program toggles port B every 2 seconds
// To test on STK500 board:
//      connect Port B to LEDs
// Written by Lam Phung [phung@uow.edu.au]

#include <avr/io.h>
#include <avr/interrupt.h>

volatile int overflow_count;

ISR(TIMER1_OVF_vect){   // handler for Timer1 overflow interrupt
	overflow_count++;    // increment overflow count 
	if (overflow_count >= 31){ 
		overflow_count = 0;   // start new count
		PORTB = ~PORTB;       // toggle port B 
	}
}

int main(void) {
    DDRB  = 0xFF;        // set port B for output
	PORTB = 0x00;        // initial value of PORTB

	TCCR1A = 0b00000000; // normal mode
	TCCR1B = 0b00000001; // no prescaler, internal clock
	TIMSK  = 0b00000100; // enable Timer 1 overflow interrupt
		
	overflow_count = 0; // initialise overflow count
	sei();              // enable interrupt subsystem globally 

	while (1){;}          // infinite loop
	return 0;
}
