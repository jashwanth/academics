// ECTE333 - Microcontroller Architecture and Applications 
// Spring session
// C progam for STK500 board & ATmega16 chip
// Display the character received through serial port on port B
// Polling approach
// Connections: PORTD.0 -> RXD pin spare
//              PORTD.1 -> TXD pin spare
// 			    PORT B  -> LEDs
// Serial tranmission parameters with Hyper Terminal: 1200 8N1
// Written by Lam Phung [phung@uow.edu.au]

#include <avr/io.h>

void USART_init(void){
    // Normal speed, disable multi-proc
	UCSRA = 0b00000000; 

    // Enable Tx and Rx, disable interrupts
	UCSRB = 0b00011000; 

    // Asynchronous mode, no parity, 1 stop bit, 8 data bits
	UCSRC = 0b10000110; 

	// Baud rate 1200bps, assuming 1MHz clock
	UBRRL = 0x33; UBRRH = 0x00;
}

int main(void) {
	USART_init(); // initialise USART
	DDRB = 0xFF;  // set port B for output
	while (1) {   // infinite loop
		while ((UCSRA & (1<<RXC)) == 0x00){;} // poll until RXC flag = 1
		PORTB = UDR;  // received character is displayed on port B
	} 
	return 0;
}
