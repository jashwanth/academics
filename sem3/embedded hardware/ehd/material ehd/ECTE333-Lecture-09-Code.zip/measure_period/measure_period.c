// ECTE333 - Spring session
// Program that uses Timer 1 Input Capture interrupt
// to measure the period of a square signal
// The high 8-bit of period is displayed on port B
// STK500 board with ATmega16 chip
// Connect: Port B to LEDs
//          Square input signal to ICP1 (D.6)
//          GRD to GRD pin of port D 
// Written by Lam Phung (phung@uow.edu.au)

#include <avr/io.h>
#include <avr/interrupt.h>
#include <inttypes.h>

volatile uint16_t period;

ISR(TIMER1_CAPT_vect){   // handler for Timer1 input capture interrupt
	period = ICR1;       // period = value of Timer 1 stored in ICR1
	TCNT1 = 0;           //	reset Timer 1
	PORTB = ~(period >> 8); // display top 8-bit of period on PORT B
}

int main(void) {
    DDRB  = 0xFF;        // set port B for output

	TCCR1A = 0b00000000; // normal mode
	TCCR1B = 0b11000001; // no prescaler, rising edge, noise canceller
	TIMSK  = 0b00100000; // enable Timer 1 input capture interrupt
	sei();               // enable interrupt subsystem globally 
	while (1){;}         // infinite loop 
	return 0;
}
