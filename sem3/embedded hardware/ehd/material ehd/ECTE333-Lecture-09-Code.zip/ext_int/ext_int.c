// ECTE333 - Spring session
// Using external interrupt INT1 in ATmega16
// The program toggles port B whenver an interrupt INT1 is triggered
// To test on STK500 board:
//      connect Port B to LEDs
//      connect pin D.3 to a switch SW7
//      connect ground pin of port D to ground pin of SW connector
// Written by Lam Phung [phung@uow.edu.au]

#include <avr/io.h>
#include <avr/interrupt.h>

ISR(INT1_vect){         // handler for INT1 interrupt
	PORTB = (~PORTB);   // toggle port B 
}

int main(void) {
	GICR = (1<< INT1);	// enable interrupt INT1
	MCUCR = (1<<ISC10); // triggered on any change to INT1 pin (D.3)
	sei();              // enable interrupt subsystem globally 
	DDRB = 0xFF;        // set port B for output
	PORTB = 0b10101010; // initial value
	while (1) {;} // infinite loop
	return 0;
}
