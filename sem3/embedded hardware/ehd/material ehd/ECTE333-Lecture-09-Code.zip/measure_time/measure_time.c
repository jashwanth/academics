// ECTE333 - Spring session
// Program that uses Timer 1 Overflow Interrupt of ATmega16
// to measure the execution time of some piece of C code
// Written by Lam Phung (phung@uow.edu.au)

#include <avr/io.h>
#include <avr/interrupt.h>
#include <inttypes.h>

volatile uint32_t n;

ISR(TIMER1_OVF_vect){   // handler for Timer1 overflow interrupt
	n++;    			// increment overflow count 
}

int main(void) {
	int i, j;
	uint32_t elapse_time;

	TCCR1A = 0b00000000; // normal mode
	TCCR1B = 0b00000001; // no prescaler, internal clock
	TIMSK  = 0b00000100; // enable Timer 1 overflow interrupt
		
	
	n = 0;               // reset n
	TCNT1 = 0;           // reset Timer 1 
	sei();               // enable interrupt subsystem globally 
    // -----  start code --------------
	for (i = 0; i < 100; i++)   
		for (j = 0; j < 1000; j++){;}
	// -----  end code --------------
	elapse_time = n * 65536 + TCNT1;
	cli();               // disable interrupt subsystem globally 
	return 0;
}
