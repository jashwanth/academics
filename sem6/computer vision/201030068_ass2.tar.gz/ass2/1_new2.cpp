#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<ctime>
#include<vector>
#include<string>
#include<iomanip>
#include<fstream>
#include<opencv2/imgproc/imgproc.hpp>
#include<opencv2/calib3d/calib3d.hpp>
#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
using namespace std;
using namespace cv;
struct point_info
{
  Point2f two_d;
  Point3f three_d;
};
struct image_info
{
  int num_of_points;
  vector<point_info> v_point;
};
int main(int argc,char* argv[])
{
  map<int,image_info>  a_m;
  int counter=0,i,j,k,img_num;
  float A[20000][12];
  FILE* fp = fopen( "ImageDetails.txt" , "r" );
  while (1)
  {
    image_info image_scan;
    point_info point_scan;
    fscanf(fp,"%d%d",&img_num,&image_scan.num_of_points);
    if(feof(fp))
      break;
//    printf("%d %d\n",img_num,num_of_points);
    for(i=0;i<image_scan.num_of_points;i++)
    {
	fscanf(fp,"%f%f%f%f%f",&point_scan.two_d.x,&point_scan.two_d.y,&point_scan.three_d.x,&point_scan.three_d.y,&point_scan.three_d.z);
        image_scan.v_point.push_back(point_scan);
    }
    a_m[img_num] = image_scan;
    image_scan.v_point.clear();
  }
  fclose(fp);
  //  checked and vimdiff of imagedetails and out worked fine :)
/*  cout << "total images " << n_o_i << endl;
  for(i=0;i<n_o_i;i++)
  {
    cout << i << ' ' << a_m[i].num_of_points << endl;
    vector<point_info>::iterator it_point = a_m[i].v_point.begin();
    for(it_point;it_point!=a_m[i].v_point.end();it_point++)
      cout << it_point->two_d.x << ' ' << it_point->two_d.y << ' ' << it_point->three_d.x << ' ' << it_point->three_d.y << ' '<< it_point->three_d.z << endl;
  }    */


 // DLT 
  int ci=0; //choose img_no
  int img_num_of_points = a_m[ci].v_point.size();
  cout << img_num_of_points << endl;
  srand(time(NULL));
  for(i=0;i<6;i++)
  {
    int i1 = rand()%img_num_of_points;
    A[counter][0]= a_m[ci].v_point[i1].three_d.x;
    A[counter][1]= a_m[ci].v_point[i1].three_d.y;
    A[counter][2]= a_m[ci].v_point[i1].three_d.z;
    A[counter][3]=1;
    A[counter][4]=0;
    A[counter][5]=0;
    A[counter][6]=0;
    A[counter][7]=0;
    A[counter][8]=   -float(a_m[ci].v_point[i1].two_d.x*a_m[ci].v_point[i1].three_d.x);
    A[counter][9]=   -float(a_m[ci].v_point[i1].two_d.x*a_m[ci].v_point[i1].three_d.y);
    A[counter][10]=  -float(a_m[ci].v_point[i1].two_d.x*a_m[ci].v_point[i1].three_d.z);
    A[counter][11]=  -a_m[ci].v_point[i1].two_d.x;
    counter++;
    A[counter][0]=0;
    A[counter][1]=0;
    A[counter][2]=0,
    A[counter][3]=0;
    A[counter][4]= a_m[ci].v_point[i1].three_d.x;
    A[counter][5]= a_m[ci].v_point[i1].three_d.y;
    A[counter][6]= a_m[ci].v_point[i1].three_d.z;
    A[counter][7]=1;
    A[counter][8]=   -float(a_m[ci].v_point[i1].two_d.y*a_m[ci].v_point[i1].three_d.x);
    A[counter][9]=   -float(a_m[ci].v_point[i1].two_d.y*a_m[ci].v_point[i1].three_d.y);
    A[counter][10]=  -float(a_m[ci].v_point[i1].two_d.y*a_m[ci].v_point[i1].three_d.z);
    A[counter][11]=  -a_m[ci].v_point[i1].two_d.y;
    counter++;
  }
  Mat Ap1 = Mat(12,12,CV_32FC1,A);
  Mat x;
  SVD::solveZ(Ap1,x);
  Mat Pcam = x.reshape(0,3);
  cout << "Pcam for DLT is :" << endl << Pcam << endl;
/*  for(i=0;i<12;i++){
    for(j=0;j<12;j++)
      printf("%f ",A[i][j]);
    printf("\n");
  }  */
  
  
  counter = 0;
  // 2.SVD
  ci=0; //choose img_no
  int i_n_o = a_m[ci].v_point.size();
  //  cout << img_num_of_points << endl;
  for(i=0;i<i_n_o;i++)
  {
    A[counter][0]= a_m[ci].v_point[i].three_d.x;
    A[counter][1]= a_m[ci].v_point[i].three_d.y;
    A[counter][2]= a_m[ci].v_point[i].three_d.z;
    A[counter][3]=1;
    A[counter][4]=0;
    A[counter][5]=0;
    A[counter][6]=0;
    A[counter][7]=0;
    A[counter][8]=   -float(a_m[ci].v_point[i].two_d.x*a_m[ci].v_point[i].three_d.x);
    A[counter][9]=   -float(a_m[ci].v_point[i].two_d.x*a_m[ci].v_point[i].three_d.y);
    A[counter][10]=  -float(a_m[ci].v_point[i].two_d.x*a_m[ci].v_point[i].three_d.z);
    A[counter][11]=  -a_m[ci].v_point[i].two_d.x;
    counter++;
    A[counter][0]=0;
    A[counter][1]=0;
    A[counter][2]=0,
    A[counter][3]=0;
    A[counter][4]= a_m[ci].v_point[i].three_d.x;
    A[counter][5]= a_m[ci].v_point[i].three_d.y;
    A[counter][6]= a_m[ci].v_point[i].three_d.z;
    A[counter][7]=1;
    A[counter][8]=   -float(a_m[ci].v_point[i].two_d.y*a_m[ci].v_point[i].three_d.x);
    A[counter][9]=   -float(a_m[ci].v_point[i].two_d.y*a_m[ci].v_point[i].three_d.y);
    A[counter][10]=  -float(a_m[ci].v_point[i].two_d.y*a_m[ci].v_point[i].three_d.z);
    A[counter][11]=  -a_m[ci].v_point[i].two_d.y;
    counter++;
  } 

  Mat Ap2 = Mat(2*i_n_o,12,CV_32FC1,A);
  SVD::solveZ(Ap2,x);
  Pcam=x.reshape(0,3);
  cout << "Pcam for SVD is: " << endl << Pcam << endl;
  /*  for(i=0;i<12;i++){
      for(j=0;j<12;j++)
      printf("%f ",A[i][j]);
      printf("\n");
      }  */
  

  // 3.RANSAC
   counter = 0;
   int max_inlers=0;
   float cumulative_error=0;
   Mat best_Pcam = Mat_<float>(12,1);
   ci = 0; // choose img no;
   i_n_o = a_m[ci].v_point.size();
   int threshold_inliners = i_n_o * 0.3;
   int n_o_i = 5000; // no of iterations;
   vector<point_info> matched_inlers;
   for(k=0;k<n_o_i;k++)
   {
     srand(time(NULL));
     vector<point_info> store_point;
     for(i=0;i<6;i++)
     {
       int r_n = rand()%i_n_o;
       store_point.push_back(a_m[ci].v_point[r_n]);

       A[counter][0]= a_m[ci].v_point[r_n].three_d.x;
       A[counter][1]= a_m[ci].v_point[r_n].three_d.y;
       A[counter][2]= a_m[ci].v_point[r_n].three_d.z;
       A[counter][3]=1;
       A[counter][4]=0;
       A[counter][5]=0;
       A[counter][6]=0;
       A[counter][7]=0;
       A[counter][8]=   -float(a_m[ci].v_point[r_n].two_d.x*a_m[ci].v_point[r_n].three_d.x);
       A[counter][9]=   -float(a_m[ci].v_point[r_n].two_d.x*a_m[ci].v_point[r_n].three_d.y);
       A[counter][10]=  -float(a_m[ci].v_point[r_n].two_d.x*a_m[ci].v_point[r_n].three_d.z);
       A[counter][11]=  -a_m[ci].v_point[r_n].two_d.x;
       counter++;
       A[counter][0]=0;
       A[counter][1]=0;
       A[counter][2]=0,
       A[counter][3]=0;
       A[counter][4]= a_m[ci].v_point[r_n].three_d.x;
       A[counter][5]= a_m[ci].v_point[r_n].three_d.y;
       A[counter][6]= a_m[ci].v_point[r_n].three_d.z;
       A[counter][7]=1;
       A[counter][8]=   -float(a_m[ci].v_point[r_n].two_d.y*a_m[ci].v_point[r_n].three_d.x);
       A[counter][9]=   -float(a_m[ci].v_point[r_n].two_d.y*a_m[ci].v_point[r_n].three_d.y);
       A[counter][10]=  -float(a_m[ci].v_point[r_n].two_d.y*a_m[ci].v_point[r_n].three_d.z);
       A[counter][11]=  -a_m[ci].v_point[r_n].two_d.y;
       counter++;
     }

     Mat Ap3 = Mat(12,12,CV_32FC1,A);
     SVD::solveZ(Ap3,x);
     Pcam = x.reshape(0,3);
     cout << "found Pcam from 6 rand points " << endl;
    // now finding errors
    float lower_limit = 0.5;
    float error[i_n_o];
    float total_error=0;
    int total_inliners=0;
    for(i=0;i<i_n_o;i++)
    {
      Point3f thr_d = a_m[ci].v_point[i].three_d;
      Point2f t_d   = a_m[ci].v_point[i].two_d;
      x = (Mat_<float>(4,1) << thr_d.x,thr_d.y,thr_d.z,1);
      Mat proj_point = Pcam*x;
      Mat img_point = (Mat_<float>(2,1) << proj_point.at<float>(0,0)/proj_point.at<float>(2,0) ,proj_point.at<float>(1,0)/proj_point.at<float>(2,0));
      Mat act_point = (Mat_<float>(2,1) << a_m[ci].v_point[i].two_d.x,a_m[ci].v_point[i].two_d.y);
      error[i] = (float)norm(img_point - act_point);
      total_error += error[i];
      if(error[i] < lower_limit)
      {
	store_point.push_back(a_m[ci].v_point[i]);
	total_inliners++;
      }
    }
    if(total_inliners > threshold_inliners)
    {
      cout << "finally found " << endl;
      max_inlers = total_inliners;
      cumulative_error = total_error;
      best_Pcam = Pcam;
      matched_inlers = store_point;
    //  store_point.clear();
      break;
    }
    else
    {
      if(total_inliners > max_inlers)
      {
	max_inlers = total_inliners;
	cumulative_error = total_error;
	best_Pcam = Pcam;
	matched_inlers = store_point;
//	store_point.clear();
      }
    }
   }
   cout << "total iterations is: " << k << endl;
   cout << "total inlers is: " << max_inlers << endl;
   cout << "reprojection error is: " << cumulative_error << endl;
   cout << "best_pcam from RANSAC is : " << endl << best_Pcam << endl;

   // finding Pcam from matched_inlers;
   counter = 0;
   i_n_o = matched_inlers.size();
   for(i=0;i<i_n_o;i++)
   {
       A[counter][0]= matched_inlers[i].three_d.x;
       A[counter][1]= matched_inlers[i].three_d.y;
       A[counter][2]= matched_inlers[i].three_d.z;
       A[counter][3]=1;
       A[counter][4]=0;
       A[counter][5]=0;
       A[counter][6]=0;
       A[counter][7]=0;
       A[counter][8]=   -float(matched_inlers[i].two_d.x*matched_inlers[i].three_d.x);
       A[counter][9]=   -float(matched_inlers[i].two_d.x*matched_inlers[i].three_d.y);
       A[counter][10]=  -float(matched_inlers[i].two_d.x*matched_inlers[i].three_d.z);
       A[counter][11]=  -matched_inlers[i].two_d.x;
       counter++;
       A[counter][0]=0;
       A[counter][1]=0;
       A[counter][2]=0,
       A[counter][3]=0;
       A[counter][4]= matched_inlers[i].three_d.x;
       A[counter][5]= matched_inlers[i].three_d.y;
       A[counter][6]= matched_inlers[i].three_d.z;
       A[counter][7]=1;
       A[counter][8]=   -float(matched_inlers[i].two_d.y*matched_inlers[i].three_d.x);
       A[counter][9]=   -float(matched_inlers[i].two_d.y*matched_inlers[i].three_d.y);
       A[counter][10]=  -float(matched_inlers[i].two_d.y*matched_inlers[i].three_d.z);
       A[counter][11]=  -matched_inlers[i].two_d.y;
       counter++;
   }
   Mat Ap4 = Mat(2*i_n_o,12,CV_32FC1,A);
   SVD::solveZ(Ap4,x);
   Pcam = x.reshape(0,3);
   cout << "Pcam from matched_classifiers is : " << endl << Pcam << endl;
  return 0;
}
