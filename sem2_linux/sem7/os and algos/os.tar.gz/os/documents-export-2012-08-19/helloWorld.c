#include<stdio.h> 
int main()
{
	printf("'ssup fellas\n");
	return 0;
}
