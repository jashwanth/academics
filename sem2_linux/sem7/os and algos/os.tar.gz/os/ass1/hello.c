#include<stdio.h>
int main(){
	int x;
	scanf("%d",&x);
	printf("HELLO WORLD %d\n",x);
	return 0;
}
