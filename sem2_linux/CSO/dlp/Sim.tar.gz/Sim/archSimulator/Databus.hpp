//	This file has Databus Module

typedef struct Databus
{
	        char DATA[WIDTH];
		char FLAG;
}Databus;

